import torch
import torch.nn.functional as F
from torch import nn
from torch.nn import init
import math

class _NonLocalNd(nn.Module):

    def __init__(self, dim, inplanes, planes, downsample, use_gn, lr_mult, use_out, whiten_type, temp, with_gc, with_nl, nowd):
        assert dim in [1, 2, 3], "dim {} is not supported yet".format(dim)
        assert with_gc or with_nl
        if dim == 3:
            conv_nd = nn.Conv3d
            if downsample:
                max_pool = nn.MaxPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2))
            else:
                max_pool = None
            bn_nd = nn.BatchNorm3d
        elif dim == 2:
            conv_nd = nn.Conv2d
            if downsample:
                max_pool = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
            else:
                max_pool = None
            bn_nd = nn.BatchNorm2d
        else:
            conv_nd = nn.Conv1d
            if downsample:
                max_pool = nn.MaxPool1d(kernel_size=2, stride=2)
            else:
                max_pool = None
            bn_nd = nn.BatchNorm1d

        super(_NonLocalNd, self).__init__()
        self.planes = planes
        self.inplanes = inplanes
        self.conv_query = conv_nd(inplanes, planes, kernel_size=1)
        self.conv_key = conv_nd(inplanes, planes, kernel_size=1)
        if use_out:
            self.conv_value = conv_nd(inplanes, planes, kernel_size=1)
            self.conv_out = conv_nd(planes, inplanes, kernel_size=1, bias=False)
        else:
            self.conv_value = conv_nd(inplanes, inplanes, kernel_size=1, bias=False)
            self.conv_out = None
        if with_gc:
            self.conv_mask = conv_nd(inplanes, 1, kernel_size=1)
        if 'bn_affine' in whiten_type:
            self.key_bn_affine = nn.BatchNorm1d(planes)
            self.query_bn_affine = nn.BatchNorm1d(planes)
        if 'bn' in whiten_type:
            self.key_bn = nn.BatchNorm1d(planes, affine=False)
            self.query_bn = nn.BatchNorm1d(planes, affine=False)
        self.softmax = nn.Softmax(dim=2)
        self.downsample = max_pool
        # without norm
        self.norm = nn.GroupNorm(num_groups=32, num_channels=inplanes) if use_gn else None  # bn_nd(num_features=inplanes, momentum=0)
        self.scale = math.sqrt(planes)
        self.whiten_type = whiten_type
        # nowd when temp == -1
        self.temp = temp
        self.nowd = nowd
        self.with_gc = with_gc
        self.with_nl = with_nl
        self.use_gn = use_gn
        self.weight_init_scale = 1.0

        self.reset_parameters()
        self.reset_lr_mult(lr_mult)
        if len(self.nowd)>0:
            self.reset_weight_and_weight_decay()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv3d) or isinstance(m, nn.Conv2d) or isinstance(m, nn.Conv1d):
                init.normal_(m.weight, 0, 0.01)
                if m.bias is not None:
                    init.zeros_(m.bias)
                m.inited = True
        if self.use_gn:
            init.constant_(self.norm.weight, 0)
            init.constant_(self.norm.bias, 0)
            self.norm.inited = True

    def reset_lr_mult(self, lr_mult):
        if lr_mult is not None:
            for m in self.modules():
                m.lr_mult = lr_mult
        else:
            print('not change lr_mult')

    def reset_weight_and_weight_decay(self):
        if self.with_nl:
            init.normal_(self.conv_query.weight, 0, 0.01 * self.weight_init_scale)
            init.normal_(self.conv_key.weight, 0, 0.01 * self.weight_init_scale)
            if 'nl' in self.nowd:
                self.conv_query.weight.wd = 0.0
                self.conv_query.bias.wd = 0.0
                self.conv_key.weight.wd = 0.0
                self.conv_key.bias.wd = 0.0
        if self.with_gc and 'gc' in self.nowd:
            self.conv_mask.weight.wd = 0.0
            self.conv_mask.bias.wd = 0.0
        if 'value' in self.nowd:
            self.conv_value.weight.wd = 0.0
            # self.conv_value.bias.wd=0.0

    def forward(self, x):
        # [N, C, T, H, W]
        residual = x
        # [N, C, T, H', W']
        if self.downsample is not None:
            input_x = self.downsample(x)
        else:
            input_x = x
            
        out=None
        # [N, C', T, H', W']
        value = self.conv_value(input_x)
        # [N, C', T x H x W]
        value = value.view(value.size(0), value.size(1), -1)
        
        if self.with_nl:
            # [N, C', T, H, W]
            query = self.conv_query(x)
            # [N, C', T, H', W']
            key = self.conv_key(input_x)
            
            # [N, C', T x H x W]
            query = query.view(query.size(0), query.size(1), -1)
            # [N, C', T x H' x W']
            key = key.view(key.size(0), key.size(1), -1)

            if 'in' in self.whiten_type:
                key_mean = key.mean(2).unsqueeze(2)
                query_mean = query.mean(2).unsqueeze(2)
                key -= key_mean
                query -= query_mean
            if 'spatial' in self.whiten_type:
                key_mean = key.mean(1).unsqueeze(1)
                query_mean = query.mean(1).unsqueeze(1)
                key -= key_mean
                query -= query_mean
            if 'bn_affine' in self.whiten_type:
                key = self.key_bn_affine(key)
                query = self.query_bn_affine(query)
            if 'bn' in self.whiten_type:
                key = self.key_bn(key)
                query = self.query_bn(query)

            # [N, T x H x W, T x H' x W']
            sim_map = torch.bmm(query.transpose(1, 2), key)
            if len(self.nowd)==0:
                sim_map = sim_map / self.scale / self.temp
            sim_map = self.softmax(sim_map)

            # [N, T x H x W, C']
            out = torch.bmm(sim_map, value.transpose(1, 2))
            # [N, C', T x H x W]
            out = out.transpose(1, 2)
            # [N, C', T,  H, W]
            out = out.view(out.size(0), out.size(1), *x.size()[2:])

        if self.with_gc:
            # [N, 1, H', W']
            mask = self.conv_mask(input_x)
            # [N, 1, H'x W']
            mask = mask.view(mask.size(0), mask.size(1), -1)
            mask = self.softmax(mask)
            # [N, C', 1, 1]
            out_gc = torch.bmm(value, mask.permute(0, 2, 1)).unsqueeze(-1)
            if out is not None:
                out = out + out_gc
            else:
                out = out_gc

        # [N, C, T,  H, W]
        if self.conv_out is not None:
            out = self.conv_out(out)
        if self.use_gn:
            out = self.norm(out)

        out = residual + out
        return out


class NonLocal2d(_NonLocalNd):

    def __init__(self, inplanes, planes, downsample, use_gn, lr_mult, use_out, whiten_type, temp, with_gc, with_nl, nowd):
        super(NonLocal2d, self).__init__(dim=2, inplanes=inplanes, planes=planes, downsample=downsample, use_gn=use_gn, 
                                         lr_mult=lr_mult, use_out=use_out, whiten_type=whiten_type, temp=temp, with_gc=with_gc, with_nl=with_nl, nowd=nowd)


class NonLocal3d(_NonLocalNd):

    def __init__(self, inplanes, planes, downsample, use_gn, lr_mult, use_out):
        super(NonLocal3d, self).__init__(dim=3, inplanes=inplanes, planes=planes, downsample=downsample, use_gn=use_gn, lr_mult=lr_mult, use_out=use_out)
