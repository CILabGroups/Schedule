#!/usr/bin/env bash
./compile.sh
pip install --user .
cd ..
git clone https://github.com/mapillary/inplace_abn.git
cd inplace_abn
python setup.py install
cd scripts
pip install -r requirements.txt
